# Example: `SyncWritePos`
