# Example: `WritePos`
