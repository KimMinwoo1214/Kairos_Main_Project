/*
 * SCServo.h
 * FIT serial servo interface
 */

#ifndef _SCSERVO_H
#define _SCSERVO_H

#include "SCSCL.h"
#include "SMS_STS.h"

#endif